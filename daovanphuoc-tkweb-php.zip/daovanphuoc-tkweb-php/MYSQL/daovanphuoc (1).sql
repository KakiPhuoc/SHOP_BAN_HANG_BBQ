-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2026 at 02:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daovanphuoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `donhang`
--

CREATE TABLE `donhang` (
  `id` int(11) NOT NULL,
  `ten_sp` varchar(255) NOT NULL,
  `gia_sp` int(11) NOT NULL,
  `ngay_dat` datetime DEFAULT current_timestamp(),
  `trang_thai` varchar(50) DEFAULT 'Chờ xử lý'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gioithieu`
--

CREATE TABLE `gioithieu` (
  `id_tt` int(11) NOT NULL,
  `tieude_tt` varchar(100) NOT NULL,
  `anh_tt` varchar(100) NOT NULL,
  `tomtat_tt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `chitiet_tt` text NOT NULL,
  `chuyenmuc_tt` varchar(100) NOT NULL,
  `tacgia_tt` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `gioithieu`
--

INSERT INTO `gioithieu` (`id_tt`, `tieude_tt`, `anh_tt`, `tomtat_tt`, `chitiet_tt`, `chuyenmuc_tt`, `tacgia_tt`) VALUES
(1, 'Chào mừng đến với Shop Đồ Nướng BBQ', 'img/gioithieu/1.jpg', 'Shop Đồ Nướng BBQ chuyên phục vụ các món nướng thơm lừng, đậm đà hương vị với công thức tẩm ướp độc quyền. Chúng tôi cam kết mang đến những bữa tiệc nướng trọn vẹn và trải nghiệm ẩm thực tuyệt vời nhất cho các buổi sum họp gia đình và bạn bè.', '', 'BBQ', 'KAKIPHUOC'),
(2, 'Nguyên liệu tươi sạch 100%', 'img/gioithieu/2.jpg', 'Thịt, bò, heo và hải sản đều được tuyển chọn kỹ lưỡng mỗi ngày, đảm bảo độ tươi ngon và an toàn vệ sinh thực phẩm.', '', 'BQQ', 'KAKIPHUOC'),
(3, 'Không gian ấm cúng, hiện đại', 'img/gioithieu/3.jpg', 'Không gian rộng rãi, trang bị hệ thống hút khói chuyên nghiệp giúp bạn thoải mái thưởng thức đồ nướng mà không lo ám mùi.', '', 'BBQ', 'KAKIPHUOC'),
(4, 'Giá cả hợp lý, phải chăng', 'img/gioithieu/4.jpg', 'Thực đơn đa dạng với mức giá phù hợp cho học sinh, sinh viên và dân văn phòng tụ tập vào cuối tuần.', '', 'BBQ', 'KAKIPHUOC');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id_sp` int(11) NOT NULL,
  `ten_sp` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `anh_sp` varchar(100) NOT NULL,
  `gia_sp` double NOT NULL,
  `chitiet_sp` text NOT NULL,
  `hang_sx` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id_sp`, `ten_sp`, `anh_sp`, `gia_sp`, `chitiet_sp`, `hang_sx`) VALUES
(1, 'Bít Tết Nướng BBQ', 'img/sp/BitTet.jpg', 399000, 'Bít tết nướng BBQ là món thịt bò thượng hạng được cắt dày dặn với những vân mỡ cẩm thạch đan xen, sau khi thấm đượm lớp sốt barbecue đậm đà hòa quyện giữa vị ngọt, chua và cay nồng, sẽ được nướng điêu luyện trên bếp than hồng để khóa chặt phần nước bên trong, mang đến những thớ thịt mềm mọng, ngọt lịm ẩn sau lớp vỏ ngoài xém cạnh vàng nâu và ngập tràn hương thơm khói đặc trưng cực kỳ kích thích vị giác.', 'BBQ'),
(2, 'Gà Cay Nướng BBQ', 'img/sp/GaCay.jpg', 499000, 'Gà Cay Nướng BBQ là món ăn đầy kích thích với những miếng thịt gà tươi ngon được tẩm ướp đẫm lớp sốt BBQ cay nồng, thấm đượm vị ngọt béo và hương tỏi ớt đặc trưng, sau đó được đem nướng chín vàng trên bếp lửa cho đến khi lớp da bên ngoài trở nên giòn dai, xém cạnh đẹp mắt, giúp khóa chặt phần nước thịt mềm mọng bên trong và dậy lên mùi khói thơm phức, vô cùng cuốn hút.', 'BBQ'),
(3, 'Xiên Nướng BBQ', 'img/sp/XienNuong.jpg', 299000, 'Xiên Nướng BBQ là sự kết hợp đầy màu sắc và ngon miệng giữa các loại thịt được cắt khối vuông vức như ba chỉ heo, bò, hoặc gà, xen kẽ với ớt chuông, hành tây và nấm tươi, tất cả được áo đều một lớp sốt BBQ đậm đà, cay ngọt hài hòa rồi nướng trực tiếp trên than hồng cho đến khi các nguyên liệu chín đều, tỏa hương khói thơm nức và cạnh xém vàng, mang lại trải nghiệm ẩm thực vô cùng thú vị và cuốn hút.', 'BBQ'),
(4, 'Xúc Xích Nướng BBQ', 'img/sp/XucXich.jpg', 199000, 'Xúc Xích Nướng BBQ là những cây xúc xích căng mọng được khía nhẹ các đường tinh tế để khi nướng trên lửa than hồng, lớp vỏ ngoài trở nên giòn rụm, xém cạnh vàng nâu và tứa ra lớp mỡ béo ngậy, quyện chặt cùng lớp sốt BBQ ngọt cay, đậm đà, tỏa ra hương khói đặc trưng cực kỳ kích thích vị giác.', 'BBQ');

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `id_sl` int(11) NOT NULL,
  `anh_sl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`id_sl`, `anh_sl`) VALUES
(1, 'img/sl/Anhdong1.jpg'),
(2, 'img/sl/Anhdong2.jpg'),
(3, 'img/sl/Anhdong3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `id` int(11) NOT NULL,
  `tendk` varchar(100) NOT NULL,
  `mk` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donhang`
--
ALTER TABLE `donhang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gioithieu`
--
ALTER TABLE `gioithieu`
  ADD PRIMARY KEY (`id_tt`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id_sp`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id_sl`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donhang`
--
ALTER TABLE `donhang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `gioithieu`
--
ALTER TABLE `gioithieu`
  MODIFY `id_tt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id_sp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id_sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `taikhoan`
--
ALTER TABLE `taikhoan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
