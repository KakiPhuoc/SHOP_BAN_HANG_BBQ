<?php
include("connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['dangky'])) {
    $tendk = trim($_POST['tendk']);
    $mk_raw = trim($_POST['mk']);
    
    // Mã hóa mật khẩu để khớp với hàm password_verify bên đăng nhập của bạn
    $mk = password_hash($mk_raw, PASSWORD_DEFAULT);

    // Kiểm tra xem tên đăng ký đã tồn tại chưa bằng Prepared Statement cho an toàn
    $stmt_check = $conn->prepare("SELECT id FROM taikhoan WHERE tendk = ?");
    $stmt_check->bind_param("s", $tendk);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "<script>alert('Tên đăng nhập này đã tồn tại, vui lòng chọn tên khác!'); window.history.back();</script>";
    } else {
        // Thực hiện thêm tài khoản mới vào cơ sở dữ liệu
        $stmt_insert = $conn->prepare("INSERT INTO taikhoan (tendk, mk) VALUES (?, ?)");
        $stmt_insert->bind_param("ss", $tendk, $mk);
        
        if ($stmt_insert->execute()) {
            // ĐĂNG KÝ THÀNH CÔNG -> Dùng Javascript ép chuyển thẳng sang file dangnhap.php
            echo "<script>
                    alert('Đăng ký tài khoản thành công! Vui lòng đăng nhập.');
                    window.location.href = 'dangnhap.php';
                  </script>";
            exit();
        } else {
            echo "<script>alert('Lỗi hệ thống: Không thể đăng ký!'); window.history.back();</script>";
        }
        $stmt_insert->close();
    }
    $stmt_check->close();
    $conn->close();
} else {
    // Nếu truy cập thẳng file này mà không qua form thì đá về trang đăng ký
    header("Location: dangky.php");
    exit();
}
?>